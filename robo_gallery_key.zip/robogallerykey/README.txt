=== Robo Gallery Key ===
Contributors: robosoft
Donate link: http://www.robosoft.co/robogallery
Tags: gallery
Requires at least: 3.6
Tested up to: 4.3
Stable tag: 1.3
License: GPL2
License URI: http://www.gnu.org/licenses/gpl.html

== Description ==

This is key plugin for Robo Gallery Pro version. You just install key as regular wordpress plugin. After installation all PRO features will be enabled automatically. Make sure that you have installed free version of the [RoboGallery](https://wordpress.org/plugins/robo-gallery) on your wesbite.

= Support =
Find help in (http://robosoft.co/clients) 

== Installation ==

You just install key as regular wordpress plugin. After installation all PRO features will be enabled automatically.

= Support =
Find help in ( http://robosoft.co/robogallery ).

== Frequently Asked Questions ==

= How to install KEY ? =

You just install key as regular wordpress plugin. After installation all PRO features will be enabled automatically.

= Support =
Find help in (http://robosoft.co/clients) 

== Screenshots ==

== Changelog ==

= 1.0 =
* Initial release (yay!)